FM STEEL TRADERS - WEBSITE
==========================

Files
-----
index.html            Home page
company.html          Company / capability page
products.html         Product range + 12 sizes
contact.html          Contact + enquiry form
return-policy.html    Return & replacement policy draft
styles.css            Website styling

Contact used on site
--------------------
Email: mujahid.fmsteeltraders@gmail.com
Mobile/WhatsApp: +91 99231 23467
Location: Chakan, Pune, Maharashtra, India

IMPORTANT
---------
This is a static website. The enquiry form opens the visitor's email program using mailto. WhatsApp buttons open WhatsApp.

The washer photos are remote representative product images. For the strongest B2B presentation, replace them with your own factory/product photos when available.

PUBLISHING OPTION 1 - GITHUB PAGES (FREE)
------------------------------------------
1. Create/login to a GitHub account at https://github.com/
2. Click New repository.
3. Name it: fm-steel-traders-website
4. Choose Public and create the repository.
5. Open the repository and click Add file -> Upload files.
6. Upload ALL files from this folder (do not upload the ZIP itself):
   index.html, company.html, products.html, contact.html, return-policy.html, styles.css
7. Click Commit changes.
8. Go to Settings -> Pages.
9. Under Build and deployment, choose Deploy from a branch.
10. Select branch main and folder / (root), then Save.
11. Wait a few minutes. GitHub will show the live website URL.
12. Open that URL and test Home, Products, Contact, email and WhatsApp buttons.

PUBLISHING OPTION 2 - NETLIFY (VERY EASY)
------------------------------------------
1. Go to https://www.netlify.com/ and create/login to an account.
2. Choose Add new project / Deploy manually (wording may change).
3. Drag the extracted fmsteel_site folder into the upload area if Netlify offers drag-and-drop deployment.
4. Netlify will create a live temporary URL.
5. You can later connect a custom domain such as fmsteeltraders.in if available.

CUSTOM DOMAIN
-------------
After the site is live, you can buy a domain from a registrar and connect it to GitHub Pages or Netlify. A professional choice could be something like fmsteeltraders.in or fmsteelwashers.in, subject to availability.

GOOGLE SITES NOTE
-----------------
Google Sites is not the best publishing method for this particular HTML package because it does not normally let you upload an arbitrary multi-page HTML/CSS website as the site itself. Use GitHub Pages or Netlify for these files.

BEFORE FINAL PUBLICATION
------------------------
- Replace representative washer images with your own product/factory photos if possible.
- Confirm the return/replacement policy with the business owner.
- Confirm material grades/tolerances/certification claims before adding them.
- Add a Google Business Profile link once the profile is created.
